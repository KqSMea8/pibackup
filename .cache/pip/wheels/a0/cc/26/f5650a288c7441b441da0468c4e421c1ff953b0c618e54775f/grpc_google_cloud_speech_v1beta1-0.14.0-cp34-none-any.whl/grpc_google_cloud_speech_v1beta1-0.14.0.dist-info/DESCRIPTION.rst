gRPC library for Google Speech

grpc-google-cloud-speech-v1beta1 is the IDL-derived library for the speech (v1beta1) service in the googleapis_ repository.

.. _`googleapis`: https://github.com/googleapis/googleapis/tree/master/google/cloud/speech/v1beta1


